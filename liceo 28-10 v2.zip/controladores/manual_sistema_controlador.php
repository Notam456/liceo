<?php 
session_start();
include($_SERVER['DOCUMENT_ROOT'] . '/liceo/includes/head.php'); 
include($_SERVER['DOCUMENT_ROOT'] . '/liceo/includes/navbar.php');
include($_SERVER['DOCUMENT_ROOT'] . '/liceo/includes/sidebar.php');
include($_SERVER['DOCUMENT_ROOT'] . '/liceo/includes/manual_sistema.php');
include($_SERVER['DOCUMENT_ROOT'] . '/liceo/includes/footer.php'); 
?>