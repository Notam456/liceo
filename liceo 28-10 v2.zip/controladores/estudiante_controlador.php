<?php
session_start();
// jose yajure, ES NECESARIO LA LINEA DEL TIMEZONE PARA QUE LA CONSTANCIA TOME LA FECHA CORRECTA
date_default_timezone_set('America/Caracas');
include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/includes/conn.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/modelos/estudiante_modelo.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/modelos/grado_modelo.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/modelos/parroquia_modelo.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/modelos/municipio_modelo.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/modelos/sector_modelo.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/modelos/profesor_modelo.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/modelos/anio_academico_modelo.php');



$estudianteModelo = new EstudianteModelo($conn);
$gradoModelo = new GradoModelo($conn);
$parroquiaModelo = new ParroquiaModelo($conn);
$municipioModelo = new MunicipioModelo($conn);
$sectorModelo = new SectorModelo($conn);
$profesorModelo = new profesorModelo($conn);
$anioAcademicoModelo = new AnioAcademicoModelo($conn);

$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'listar';

switch ($action) {
    case 'crear':
        if (isset($_POST['save_data'])) {
            $resultado = $estudianteModelo->crearEstudiante(
                $_POST['nombre_estudiante'],
                $_POST['apellido_estudiante'],
                $_POST['cedula_estudiante'],
                $_POST['contacto_estudiante'],
                $_POST['sector'],
                $_POST['grado'],
                $_POST['fecha_nacimiento'],
                $_POST['direccion_exacta'],
                $_POST['punto_referencia']
            );
            if ($resultado === true) {
                $_SESSION['status'] = "Estudiante creado correctamente";
            } elseif ($resultado === 1062) {
                $_SESSION['status'] = "La cédula ya existe. Intente con otra.";
            } else {
                $_SESSION['status'] = "Ocurrió un error inesperado.";
            }
            header('Location: /liceo/controladores/estudiante_controlador.php');
            exit();
        }
        break;

    case 'ver':
        if (isset($_POST['id_estudiante'])) {
            $id = $_POST['id_estudiante'];
            $resultado = $estudianteModelo->obtenerEstudiantePorId($id);
            if (mysqli_num_rows($resultado) > 0) {
                $row = mysqli_fetch_array($resultado);

                include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/vistas/modals/estudiante_modal_view.php');
            } else {

                $row = [];
                include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/vistas/modals/estudiante_modal_view.php');
            }
        }
        break;

    case 'editar':
        if (isset($_POST['id_estudiante'])) {
            $id = $_POST['id_estudiante'];
            $resultado = $estudianteModelo->obtenerEstudiantePorId($id);
            $data = [];
            while ($row = mysqli_fetch_assoc($resultado)) {
                $data[] = $row;
            }
            header('Content-Type: application/json');
            echo json_encode($data);
        }
        break;

    case 'actualizar':
        if (isset($_POST['update-data'])) {
            $resultado = $estudianteModelo->actualizarEstudiante(
                $_POST['id_estudiante'],
                $_POST['nombre_estudiante'],
                $_POST['apellido_estudiante'],
                $_POST['cedula_estudiante'],
                $_POST['contacto_estudiante'],
                $_POST['sector'],
                $_POST['grado'],
                $_POST['fecha_nacimiento'],
                $_POST['direccion_exacta'],
                $_POST['punto_referencia']
            );
            if ($resultado === true) {
                $_SESSION['status'] = "Datos actualizados correctamente";
            } elseif ($resultado === 1062) {
                $_SESSION['status'] = "La cédula ya existe. Intente con otra.";
            } else {
                $_SESSION['status'] = "Ocurrió un error inesperado.";
            }
            header('Location: /liceo/controladores/estudiante_controlador.php');
            exit();
        }
        break;

    case 'eliminar':
        if (isset($_POST['id_estudiante'])) {
            $id = $_POST['id_estudiante'];
            $resultado = $estudianteModelo->eliminarEstudiante($id);
            echo $resultado ? "Datos eliminados correctamente" : "Los datos no se han podido eliminar";
        }
        break;

    case 'listarPorSeccion':
        if (isset($_GET['id_seccion'])) {
            $id_seccion = $_GET['id_seccion'];
            $estudiantes = $estudianteModelo->obtenerEstudiantesPorSeccion($id_seccion);
            include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/vistas/estudiante_vista.php');
        }
        break;
    // jose yajure, AÑADIR TCPDF PARA GENERAR EL ARCHIVO EN PDF!!
    case 'generar_constancia':
        while (ob_get_level()) {
            ob_end_clean();
        }
        if (isset($_GET['id'])) {
            $id_estudiante = $_GET['id'];
            $resultado = $estudianteModelo->obtenerEstudiantePorId($id_estudiante);

            $director = $profesorModelo->obtenerDirector();
            $result_periodo = $anioAcademicoModelo->obtenerAnioActivo();

            $periodo_escolar = "Año Escolar no definido";
            if ($result_periodo && mysqli_num_rows($result_periodo) > 0) {
                $periodo = mysqli_fetch_assoc($result_periodo);
                $desde = date('m-Y ', strtotime($periodo['desde']));
                $hasta = date(' m-Y', strtotime($periodo['hasta']));
                $periodo_escolar = $desde . '-' . $hasta;
            }

            if ($row = mysqli_fetch_array($resultado)) {
                require_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/TCPDF/tcpdf.php');

                $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

                $pdf->SetCreator(PDF_CREATOR);
                $pdf->SetAuthor('Liceo');
                $pdf->SetTitle('Constancia de Estudio');
                $pdf->SetSubject('Constancia de Estudio para Estudiante');
                $pdf->setPrintHeader(false);
                $pdf->setPrintFooter(false);
                $pdf->AddPage();

                $dias = ["Sunday" => "Domingo", "Monday" => "Lunes", "Tuesday" => "Martes", "Wednesday" => "Miércoles", "Thursday" => "Jueves", "Friday" => "Viernes", "Saturday" => "Sábado"];
                $dia_actual = $dias[date('l')];

                $fecha_actual = date('d/m/Y');


                $membrete_path = $_SERVER['DOCUMENT_ROOT'] . '/liceo/imgs/membrete.png';
                $ancho_imagen = 180;
                $posicion_x = ($pdf->getPageWidth() - $ancho_imagen) / 2;

                $pdf->Image($membrete_path, $posicion_x, 5, $ancho_imagen, '', '', '', '', false, 300, '', false, false, 0);

                $pdf->SetMargins(15, 60, 15);
                $pdf->SetY(50);

                $nombre_director = $director ? $director['nombre'] . ' ' . $director['apellido'] : 'NOMBRE DEL DIRECTOR';
                $cedula_director = $director ? $director['cedula'] : 'C.I DEL DIRECTOR';

                // $periodo_escolar = date('F Y', strtotime($periodo['desde'])) . ' - ' . date('F Y', strtotime($periodo['hasta']));

                // jose yajure, EN EL PARRAFO DIRECTOR HAY QUE COLOCAR LA CONSULTA 
                //QUE NOS TRAIGA EL NOMBRE Y CEDULA DEL DIRECTOR!!

                $html = '
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr>
                            <td colspan="3" style="text-align: center;"><h1>CONSTANCIA DE ESTUDIO</h1></td>
                        </tr>
                    </table>

                    ' . $pdf->Ln(10) . '
    
                    <p style="text-align: justify; line-height: 1.5;">
                        Quien suscribe Prof.<strong style="text-transform: uppercase;"> ' . $nombre_director . ', </strong> titular de la Cédula de Identidad 
                        N°<strong style="text-transform: uppercase;">' . $cedula_director . '</strong> Director del 
                        <strong style="text-transform: uppercase;">LICEO PROFESOR FERNANDO RAMÍREZ</strong> ubicada en el Barrio las Madres detrás del Polideportivo San Felipe Edo. Yaracuy. 
                        Hace constar por medio de la presente que el (la) Estudiante <strong style="text-transform: uppercase;">' .
                    $row['nombre'] . ' ' . $row['apellido'] . '</strong>, titular de la Cédula <strong style="text-transform: uppercase;"> ' .
                    $row['cedula'] . ' </strong>, cursa el<strong> Año ' . $row['numero_anio'] . ' Seccion ' . $row['letra'] .
                    '</strong> durante el periodo escolar<strong> ' . $periodo_escolar .
                    '</strong> de Educación Secundaria y Reside en el Municipio:<strong> ' . $row['municipio'] .
                    '</strong> Parroquia: <strong>' . $row['parroquia'] . '</strong> Sector: <strong>' . $row['sector'] . '</strong>
                    </p>
                    <br>
                    <p style="text-align: justify;">
                        Constancia que se expide en San Felipe, hoy ' . $dia_actual . ' de fecha ' . $fecha_actual . '
                    </p>
                    <br>
                ';

                $pdf->writeHTML($html, true, false, true, false, '');

                $pdf->Ln(30);
                // jose yajure, AÑADÍ $html2 YA QUE EL TCPDF NO ME LEE MAS DE UN <br>
                // TUVE QUE USAR LA FUNCIONA Ln PARA PODER AÑADIR MAS ESPACIO EN DONDE SE FIRMA Y SELLA
                $html2 = '                    
                <p style="text-align: center;">__________________________________</p>
                <p style="text-align: center;">Prof. ' . $nombre_director . '</p> 
                <p style="text-align: center;">Barrio Las Madres</p>
                <p style="text-align: center;">Municipio San Felipe</p>';

                $pdf->writeHTML($html2, true, false, true, false, '');

                $file_name = "Constancia_" . $row['nombre'] . "_" . $row['apellido'] . ".pdf";
                $pdf->Output($file_name, 'I');
                exit;
            } else {
                echo "No se encontró el estudiante con el ID proporcionado.";
            }
        }
        break;

    case 'get_parroquias':
        if (isset($_POST['municipio_id'])) {
            $municipio_id = $_POST['municipio_id'];
            $parroquias = $parroquiaModelo->obtenerParroquiasPorMunicipio($municipio_id);
            $data = [];
            while ($row = mysqli_fetch_assoc($parroquias)) {
                $data[] = $row;
            }
            header('Content-Type: application/json');
            echo json_encode($data);
        }
        break;

    case 'get_sectores':
        if (isset($_POST['parroquia_id'])) {
            $parroquia_id = $_POST['parroquia_id'];
            $sectores = $sectorModelo->obtenerSectoresPorParroquia($parroquia_id);
            $data = [];
            while ($row = mysqli_fetch_assoc($sectores)) {
                $data[] = $row;
            }
            header('Content-Type: application/json');
            echo json_encode($data);
        }
        break;

    case 'listar':
    default:
        $estudiantes = $estudianteModelo->obtenerTodosLosEstudiantes();
        include_once($_SERVER['DOCUMENT_ROOT'] . '/liceo/vistas/estudiante_vista.php');
        break;
}
