<footer class="bg-dark mt-auto" style="color: white;">
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-12 text-center">
                <h6 class="mb-0 text-center small" style="color: white;">
                    @José Yajure - Roberto Vielma - Yhoenyer Alvarado - Jose Luis Peralta - Jose Gonzalez - Daniel Alejos
                </h6>
            </div>
        </div>
    </div>
</footer>
