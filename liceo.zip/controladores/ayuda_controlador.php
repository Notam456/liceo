<?php
session_start();
include($_SERVER['DOCUMENT_ROOT'] . '/liceo/vistas/ayuda_vista.php');
?>