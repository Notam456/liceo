<?php

include($_SERVER['DOCUMENT_ROOT'] . '/liceo/vistas/reporte_vista.php');
?>